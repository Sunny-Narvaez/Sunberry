package com.sunny.restaurant_reservation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SunberryApplication {

	public static void main(String[] args) {
		SpringApplication.run(SunberryApplication.class, args);
	}

}
