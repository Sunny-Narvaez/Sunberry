package com.sunny.restaurant_reservation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SunberryApplicationTests {

	@Test
	void contextLoads() {
	}

}
